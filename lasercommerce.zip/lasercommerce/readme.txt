=== LaserCommerce ===
Contributors: Derwent
Donate link:
Tags:
License: 
License URI: 
Requires at least: 3.5
Tested up to: 3.5
Stable tag: 0.1

An all-in-one solution for WooCommerce stores that need fine-grained control over their products pricing and visibility for an arbitrary number of pri

== Description ==

An all-in-one solution for WooCommerce stores that need fine-grained control over their products pricing and visibility for an arbitrary number of pri

== Installation ==


== Frequently Asked Questions ==


== Screenshots ==


== Changelog ==

= 0.1 =
- Initial Revision
